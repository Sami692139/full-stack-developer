var group1 = document.getElementById("li");
console.log(group1);